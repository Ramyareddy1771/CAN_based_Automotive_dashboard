
#include <xc.h>
#include "adc.h"

void init_adc(void)
{
    //con0
    ADON = 0; //turn off ADC
    
    
    //con1
    PCFG0 = 0;
    PCFG1 = 0;
    PCFG2 = 0;
    PCFG3 = 0;  //setting all pins as analog
    
    VCFG0 = 0;
    VCFG1 = 0;  //default reference voltage
    
    //con2
    ADCS0 = 0;
    ADCS1 = 1;
    ADCS2 = 0;  //FOSC / 32 clock conversion so 1TAD = 1.6 micro sec
    
    ACQT0 = 0 ;
    ACQT1 = 1;
    ACQT2 = 0;  //for 4 TAD aquisation time -> 6.4 u
    
    ADFM = 1;  //right justified
    
       ADON = 1; //turn on ADC

}

unsigned short read_adc(unsigned char channel)
{
    ADCON0 = (ADCON0 & 0xc3 ) | (channel << 2);  // clear and load channel
    
    GO = 1; //started the conversion
    
    while(GO); //until progress 
    
    return  (((ADRESH << 8) | ADRESL) );  // ADRESH is unsigned char and 8 is int (implicit conversion) so ADRESH will become int (16 bits)
    
}

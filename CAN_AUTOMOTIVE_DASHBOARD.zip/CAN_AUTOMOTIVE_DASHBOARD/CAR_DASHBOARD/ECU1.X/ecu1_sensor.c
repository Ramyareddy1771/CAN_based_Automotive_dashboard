
#include<xc.h>
#include<stdint.h>

#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "dkp.h"
//#include "uart.h"


/* speed reading from potentiometer - connected to CH4 */
uint16_t get_speed()
{
     return read_adc(CHANNEL4);
}

/* gear position reading from dig key pad */
unsigned char get_gear_pos()
{
   
    unsigned char key = read_digital_keypad(STATE_CHANGE);

    static unsigned char gear_index = 0;
    switch(key)
    {
        
        case GEAR_UP: /* increment in gear */
            if(gear_index < 6)//6
            { 
                gear_index++;
                return gear_index;
            }
            
        case GEAR_DOWN: /* decrement */
            if(gear_index > 0)
            {
                gear_index--;
                return gear_index;
            }
            
        case COLLISION: /* if any accident occurring */
            return 7;           
    }
    return gear_index;
}
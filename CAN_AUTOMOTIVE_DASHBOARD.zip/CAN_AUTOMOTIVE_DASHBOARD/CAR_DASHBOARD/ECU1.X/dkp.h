/* 
 * File:   dkp.h
 * Author: Dell
 *
 * Created on 26 August, 2026, 4:30 PM
 */

#ifndef DKP_H
#define DKP_H

#define LEVEL					     	0
#define STATE_CHANGE			       	1

#define KEY_PORT					PORTC

#define SW1					0x0E
#define SW2					0x0D
#define SW3					0x0B
#define SW4					0x07
#define ALL_RELEASED					0x0F

#define INPUT_PINS					0x0F

void init_digital_keypad(void);
unsigned char read_digital_keypad(unsigned char detection_type);

#endif
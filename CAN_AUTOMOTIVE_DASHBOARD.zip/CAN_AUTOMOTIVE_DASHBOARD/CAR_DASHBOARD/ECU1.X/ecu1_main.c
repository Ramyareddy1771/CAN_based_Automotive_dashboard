/*
 * File:   ecu1_main.c
 * Created on 26 August, 2026, 4:28 PM
  
 NAME    :  RAMYA AMBATI
 REGNO   :  25048_059
 
ECU1 – Speed and Gear ECU
******************************
1.ECU1 is responsible for acquiring the vehicle speed and gear position information.
2.It is implemented using the PIC18F4580 microcontroller.
3.Vehicle speed is obtained from an analog input connected to ADC Channel 4.
4.The ADC value is converted into a suitable speed value using an ADC scaling factor.
5.Gear position is selected using a digital keypad.
6.The ECU supports different gear states such as Neutral, G1–G5 and Reverse.
7.A separate keypad input is also provided to indicate a collision/accident condition.
8.The current gear position is maintained using a static gear index.
9.Gear-up and gear-down operations increment or decrement the current gear.
10.ECU1 initializes the ADC, CAN and Digital Keypad peripherals during startup.
11.The processed speed information is transmitted through the CAN bus using message ID 0x10.
12.The gear information is transmitted using CAN message ID 0x20.
13.Thus, ECU1 acts as the sensor/input ECU for speed and gear information.
14.ECU1 communicates with the dashboard ECU without directly controlling the display.
The main concepts implemented are ADC, Digital Keypad, CAN communication and embedded C.
*/

#include<xc.h>
#include<stdint.h>

#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include "dkp.h"
//#include "uart.h"

uint16_t msg_id;
uint8_t data, data1;
uint8_t  len;
void init_config()
{
    init_adc();
    init_can();
    init_digital_keypad();
}
int main()
{
    init_config();
    //init_uart();
    
    uint8_t sp;
    uint8_t gear;
    unsigned int delay;
  
    while(1)
    {
        /* speed calculation */
        sp = get_speed() / 10.23;
        
        /* gear position  */
        gear = get_gear_pos();
        
        /* UART */
//        putch(sp/100 + '0');
//        putch(((sp/10 ) % 10 )+ '0');
//        putch((sp % 10) + '0');
//        puts("\r\n");
        
        /* transmit speed */
            can_transmit(SPEED_MSG_ID, &sp, 1);

        for(delay = 1000;delay--;);
        
        //can_receive(&msg_id, &data, &len);
        
//        /* UART */
//        if(msg_id == SPEED_MSG_ID)
//        {
//            putch((data / 100) + '0');
//            putch(((data / 10) % 10) + '0');
//            putch((data % 10) +'0');
//        }

        
                /* transmit gear */
            can_transmit(GEAR_MSG_ID, &gear, 1);

            for(delay = 2000;delay--;);
            
            //can_receive(&msg_id, &data1, &len);
            
            /* UART */
//                if(gear == 0)
//                    puts("GN");
//                else if(gear == 1)
//                    puts("G1");
//                else if(gear == 2)
//                    puts("G2");
//                else if(gear == 3)
//                    puts("G3");
//                else if(gear == 4)
//                    puts("G4");
//                else if(gear == 5)
//                    puts("G5");
//                else if(gear == 6)
//                    puts("GR");
//                else 
//                    puts("_c");
            }

    }
    



/*
 NAME    :  RAMYA AMBATI
 REGNO   :  25048_059

ECU2 – RPM and Indicator ECU
*****************************
1. ECU2 is responsible for acquiring the engine RPM and indicator status.
2. It is implemented using the PIC18F4580 microcontroller.
3. Engine RPM is obtained from an analog input connected to ADC Channel 4.
4. The ADC value is processed and scaled to generate the corresponding RPM value.
5. The ECU uses a digital keypad to control the vehicle indicators.
6. Four keypad inputs are used for left indicator, right indicator, hazard and OFF.
7. The indicator state is stored using an IndicatorStatus enumeration.
8. When the left switch is pressed, the ECU selects the left indicator.
9. When the right switch is pressed, the ECU selects the right indicator.
10. The hazard switch activates both left and right indicator status.
11. The fourth switch is used to turn the indicators OFF.
12. ECU2 initializes the ADC, CAN and Digital Keypad peripherals.
13. RPM information is transmitted through CAN using message ID 0x30.
14. Indicator information is transmitted using message ID 0x40.
15. Therefore, ECU2 acts as the engine/indicator input ECU and sends the processed data to ECU3.
*/
#include <xc.h>

#include "adc.h"
#include "dkp.h"
#include "can.h"
#include "ecu2_sensor.h"
#include "msg_id.h"
//#include "uart.h"

#include <stdint.h>


void init_conf(void)
{
    
    init_adc();
    //init_uart();

    init_can();
    init_digital_keypad();
}

void main(void)
{
    init_conf();
    
    uint8_t len;
    uint16_t data2,msg_id,data1[4];
    
    while (1) 
    {
        //RPM
        uint16_t rpm = get_rpm();   
        
        // INd
        IndicatorStatus data = process_indicator();
        
        /* UART */
//         putch(rpm / 1000 + '0');
//         putch(((rpm / 100) % 10) + '0');
//          putch(((rpm / 10) % 10) + '0');
//          putch((rpm % 10) + '0');
//          puts("\r\n");
          
        can_transmit(RPM_MSG_ID, &rpm, 2);
        for(unsigned int delay = 3000; delay--;);

        /* UART */
//        if(data == e_ind_left)
//            puts("<-\r\n");
//        else if(data == e_ind_right)
//            puts("->\r\n");
//        else if(data == e_ind_hazard)
//            puts("<->\r\n");\
//        else if(data == e_ind_off)
//            puts("off\r\n");
        
        can_transmit(INDICATOR_MSG_ID,&data,2);
        
        for(unsigned int delay = 4000; delay--;);
    }
}
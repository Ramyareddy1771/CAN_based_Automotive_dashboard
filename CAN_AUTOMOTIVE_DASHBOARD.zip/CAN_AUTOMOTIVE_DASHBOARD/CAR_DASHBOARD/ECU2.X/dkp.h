/* 
 * File:   dkp.h
 * Author: Dell
 *
 * Created on 26 August, 2026, 4:34 PM
 */

#ifndef DKP_H
#define	DKP_H


#define LEVEL					     	0
#define STATE_CHANGE			       	1

#define KEY_PORT					PORTC

#define SWITCH1					0x0E
#define SWITCH2					0x0D
#define SWITCH3					0x0B
#define SWITCH4					0x07
#define ALL_RELEASED					0x0F

#define INPUT_PINS					0x0F

void init_digital_keypad(void);
unsigned char read_digital_keypad(unsigned char detection_type);


#endif	/* DKP_H */


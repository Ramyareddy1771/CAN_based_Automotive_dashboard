/* 
 * File:   ecu2_sensor.h
 * Author: Dell
 *
 * Created on 26 August, 2026, 4:36 PM
 */

#ifndef ECU2_SENSOR_H
#define	ECU2_SENSOR_H

#include <stdint.h>
#include "dkp.h"
#include <xc.h>

#define RPM_ADC_CHANNEL 0x04
#define ENG_TEMP_ADC_CHANNEL 0x06

#define LED_OFF 0
#define LED_ON 1

#define RIGHT_IND_ON() (PORTB = PORTB | 0xC0)
#define RIGHT_IND_OFF() (PORTB = PORTB & ~0xC0)
#define LEFT_IND_ON() (PORTB = PORTB | 0x03)
#define LEFT_IND_OFF() (PORTB = PORTB & ~0x03)

typedef enum {
    e_ind_off,
    e_ind_left,
    e_ind_right,
    e_ind_hazard
} IndicatorStatus; 

 volatile IndicatorStatus prev_ind_status, status;
extern volatile unsigned char led_state;

unsigned int get_rpm();
IndicatorStatus process_indicator();

#endif	/* ECU2_SENSOR_H */


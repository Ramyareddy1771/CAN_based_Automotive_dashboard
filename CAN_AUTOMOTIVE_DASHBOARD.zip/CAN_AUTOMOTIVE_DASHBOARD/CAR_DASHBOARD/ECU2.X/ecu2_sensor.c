
#include<xc.h>
#include<stdint.h>

#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "dkp.h"
#include "uart.h"


unsigned int get_rpm()
{
   //Implement the rpm function
     unsigned int adc_value = (read_adc(CHANNEL4) / 10.23)*60;

    return adc_value ;
}



IndicatorStatus process_indicator()
{
    unsigned char key = read_digital_keypad(STATE_CHANGE);
    
    static IndicatorStatus status = e_ind_off;
    
    switch(key)
    {
        case SWITCH1:
            status = e_ind_left;
            break;
        case SWITCH2:
            status = e_ind_right;
            break;
        case SWITCH3:
            status = e_ind_hazard;
            break;
        case SWITCH4:
            status = e_ind_off;
            break;
        default:
            break;
            
    }
    return status;
}
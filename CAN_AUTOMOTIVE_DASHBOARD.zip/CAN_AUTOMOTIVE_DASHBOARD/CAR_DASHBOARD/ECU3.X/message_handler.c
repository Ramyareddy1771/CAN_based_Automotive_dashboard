
#include <xc.h>
#include <string.h>
#include <stdint.h>

#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"
//#include "uart_1.h"

volatile unsigned char led_state = LED_OFF;
volatile unsigned char status = e_ind_off;

unsigned char Gear[8][3] = { "GN" , "G1" , "G2", "G3", "G4", "G5", "GR","_c"};

/* ---------------- SPEED ---------------- */
void handle_speed_data(uint8_t *data, uint8_t len)
{
    uint8_t sp;
    
    if(len < 1)
        return;
    
       sp = data[0];
       
       /* UART */
//       putch((sp / 100) + '0');
//       putch(((sp / 10) % 10) + '0');
//       putch((sp % 10) + '0');
      
       /* CAN */
      clcd_putch((sp / 100) + '0', LINE2(0));
      clcd_putch(((sp / 10) % 10) + '0', LINE2(1));
      clcd_putch((sp % 10) + '0', LINE2(2));
      
}

/* ---------------- GEAR ---------------- */
void handle_gear_data(uint8_t *data, uint8_t len) 
{

    if (len < 1)
        return;

        /* UART */
      //  puts(Gear[index]);   
       
       // clcd_print(Gear[index], LINE2(4));
        
        clcd_print("   ", LINE2(4));
    clcd_print(Gear[data[0]], LINE2(4));

}

/* ---------------- RPM ---------------- */
void handle_rpm_data(uint16_t *data, uint8_t len) 
{

    if (len < 2)
        return;
    
    /* UART */
//    putch((rpm / 1000) + '0');
//    putch(((rpm / 100) % 10) + '0');
//    putch(((rpm / 10) % 10) + '0');
//    putch((rpm % 10) + '0');
    
    /* CAN */
    uint16_t value = 0;
    
    for(uint16_t i= 0; i < len; i++)
    {
        value = (value << 8) | data[i];
    }
    
    clcd_print("      ", LINE2(8));
    clcd_putch((value / 1000) + '0', LINE2(8));
    clcd_putch((( value / 100) % 10) + '0', LINE2(9));
    clcd_putch((( value / 10) % 10) + '0', LINE2(10));
    clcd_putch(( value % 10) + '0', LINE2(11));
    

}

/* ---------------- INDICATOR ---------------- */
void handle_indicator_data(uint8_t *data, uint8_t len) 
{
//    if (len < 1)
//        return;
    
    status = data[0];
    
    if(status == e_ind_left)
    {
        //puts("left<-\r\n");
        
        clcd_print("   ", LINE2(13));
        clcd_print("<-",LINE2(13));
        
        if(led_state)
            LEFT_IND_ON();
        else
            LEFT_IND_OFF();
        
        RIGHT_IND_OFF();
        
    }
    else if(status == e_ind_right)
    {
       // puts("right->\r\n");
        
        clcd_print("   ", LINE2(13));
        clcd_print("->", LINE2(13));
        
        if(led_state)
            RIGHT_IND_ON();
        else
            RIGHT_IND_OFF();
        
        LEFT_IND_OFF();
    }
    else if(status == e_ind_hazard)
    {
       // puts("hazard<->\r\n");
        
        clcd_print("   ", LINE2(13));
        clcd_print("<->", LINE2(13));
        
        if(led_state)
        {
            LEFT_IND_ON();
            RIGHT_IND_ON();
            
        }
        else
        {
            LEFT_IND_OFF();
            RIGHT_IND_OFF();
        }
    }
    else if(status == e_ind_off)
    {
       // puts("off__\r\n");
        
        clcd_print("   ", LINE2(13));
        clcd_print("__", LINE2(13));
        
        LEFT_IND_OFF();
        RIGHT_IND_OFF();

    }
}

void process_canbus_data() 
{   
    //process the CAN bus data
    uint16_t msg_id;
    uint8_t data[8];
    uint8_t len;

    
    can_receive(&msg_id, data, &len);
  
    if(len == 0)
    {
        return;
    }

//    clcd_putch((*data / 100) + '0', LINE2(0));
//      clcd_putch(((*data / 10) % 10) + '0', LINE2(1));
//      clcd_putch((*data % 10) + '0', LINE2(2));
    
    switch(msg_id)
    {
        case SPEED_MSG_ID:
            
            handle_speed_data(data, len);
            break;

        case GEAR_MSG_ID:
            
            handle_gear_data(data, len);
            break;

        case RPM_MSG_ID:
            
            handle_rpm_data(data, len);
            break;

        case INDICATOR_MSG_ID:
            
            handle_indicator_data(data, len);
            break;
            
    }

}
/* 
 * File:   timer0.h
 * Author: Dell
 *
 * Created on 26 August, 2026, 4:43 PM
 */

#ifndef TIMER0_H
#define TIMER0_H

void init_timer0(void);

#endif


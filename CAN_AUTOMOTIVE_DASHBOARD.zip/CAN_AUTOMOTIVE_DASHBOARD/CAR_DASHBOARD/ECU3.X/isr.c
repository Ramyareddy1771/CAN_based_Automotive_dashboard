
#include<xc.h>
#include"timer0.h"
#include "message_handler.h"

void __interrupt() isr()
{

    static unsigned int count = 0;
    if(TMR0IF)
    {
        TMR0 = TMR0 + 8;
        
        if(++count >= 20000)
        {
            count = 0;
            led_state = !led_state;
        
        }
       TMR0IF = 0;     
    }
    
}

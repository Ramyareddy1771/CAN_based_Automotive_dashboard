/*
 * File:   main.c
 *
 * Created on 26 August, 2026, 4:41 PM
 * 
 NAME    :  RAMYA AMBATI
 REGNO   :  25048_059
 
 * ECU3 – Dashboard / Display ECU
********************************
1. ECU3 acts as the central dashboard ECU of the automotive system.
2. It is implemented using the PIC18F4580 microcontroller.
3. ECU3 receives speed, gear, RPM and indicator information from ECU1 and ECU2 through CAN communication.
4. It initializes the CAN controller, 16×2 CLCD, LEDs and Timer0 during startup.
5. The dashboard displays the parameters using the format SPD, GR, RPM and IND.
6. Speed data received with CAN ID 0x10 is converted into digits and displayed on the CLCD.
7. RPM data received with CAN ID 0x30 is reconstructed from the received bytes and displayed on the CLCD.
8. Indicator data received with CAN ID 0x40 determines the left, right, hazard or OFF indication.
9. ECU3 controls the left and right indicator LEDs according to the received indicator status.
10. Timer0 interrupt is used to periodically change the LED state.
11. This produces the blinking effect required for the vehicle indicators.
12. In hazard mode, both indicator LEDs are controlled together.
13. A CAN message handler identifies the received message ID and calls the corresponding processing function.
14. Thus, ECU3 integrates all ECU data and provides the final visual dashboard output.
 */


#include <xc.h>
#include <stdint.h>

#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "message_handler.h"
#include "timer0.h"
//#include "uart_1.h"


static void init_leds()
{
    TRISB = 0x08; // Set RB2 as output, RB3 as input, remaining as output
    PORTB = 0x00;
}

static void init_config(void)
{
    // Initialize CLCD and CANBUS
    init_leds();
    init_can();
    init_clcd();
    //init_uart();
    

    // Enable Interrupts
    PEIE = 1;
    GIE = 1;
    
    init_timer0();
}

void main(void) 
{
    // Initialize peripherals
    init_config();
    clcd_print("SPD GR  RPM IND", LINE1(0));

    /* ECU1 main loop */
    while (1)
    {
        // Read CAN Bus data and handle it
        process_canbus_data();
    }

    return;
}

